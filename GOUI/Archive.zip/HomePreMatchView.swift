import SwiftUI

struct HomePreMatchView: View {

    @ObservedObject var store: MatchStore
    var teamStore: TeamStore
    @Binding var selectedTeamID: UUID?

    private let teal = Color(red: 0.00, green: 0.73, blue: 0.70)

    private var teams: [Team] { teamStore.teams }

    private var selectedTeam: Team? {
        guard let id = selectedTeamID else { return nil }
        return teams.first(where: { $0.id == id })
    }

    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {

                    // Header
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Start Match")
                            .font(.system(size: 26, weight: .semibold))
                        Text("Select a team, then jump into Match View.")
                            .font(.system(size: 13))
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.top, 14)

                    // Team Picker Card
                    VStack(alignment: .leading, spacing: 12) {
                        Text("TEAM")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.secondary)

                        if teams.isEmpty {
                            Text("No teams yet. Create one on Home.")
                                .font(.system(size: 14))
                                .foregroundStyle(.secondary)
                        } else {
                            Menu {
                                ForEach(teams, id: \.id) { t in
                                    Button {
                                        selectedTeamID = t.id
                                    } label: {
                                        Text(t.name.isEmpty ? "Untitled Team" : t.name)
                                    }
                                }
                            } label: {
                                HStack {
                                    Text(selectedTeam?.name.isEmpty == false ? selectedTeam!.name : "Select Team")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(.primary)
                                    Spacer()
                                    Image(systemName: "chevron.down")
                                        .foregroundStyle(.secondary)
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 12)
                                .background(
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(Color(uiColor: .secondarySystemGroupedBackground))
                                )
                            }
                        }
                    }
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(Color(uiColor: .systemBackground))
                            .shadow(color: .black.opacity(0.06), radius: 18, x: 0, y: 10)
                    )
                    .padding(.horizontal, 16)

                    // Start Match Button (goes to MatchView)
                    if let tid = selectedTeamID {
                        NavigationLink {
                            MatchView(teamStore: teamStore, teamID: tid)
                        } label: {
                            Text("Start Match")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(
                                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .fill(teal)
                                )
                                .padding(.horizontal, 16)
                        }
                        .buttonStyle(.plain)
                    } else {
                        Text("Select a team to continue.")
                            .font(.system(size: 13))
                            .foregroundStyle(.secondary)
                            .padding(.top, 6)
                    }

                    Spacer(minLength: 30)
                }
                .padding(.bottom, 60)
            }
        }
        .navigationTitle("Match")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if selectedTeamID == nil {
                selectedTeamID = teamStore.teams.first?.id
            }
        }
    }
}

