import SwiftUI

struct MainTabsView: View {

    @ObservedObject var store: MatchStore
    var teamStore: TeamStore
    @Binding var selectedTeamID: UUID?

    // Preferred init (Binding)
    init(store: MatchStore, teamStore: TeamStore, selectedTeamID: Binding<UUID?>) {
        self.store = store
        self.teamStore = teamStore
        self._selectedTeamID = selectedTeamID
    }

    // Back-compat init (if anything still calls with UUID)
    init(store: MatchStore, teamStore: TeamStore, teamID: UUID) {
        self.store = store
        self.teamStore = teamStore
        self._selectedTeamID = .constant(Optional(teamID))
    }

    var body: some View {
        TabView {

            // HOME
            NavigationStack {
                // ✅ HomeView expects a Binding<UUID?> now
                HomeView(
                    store: store,
                    teamStore: teamStore,
                    selectedTeamID: $selectedTeamID
                )
            }
            .tabItem { Label("Home", systemImage: "house") }

            // MATCH (Pre-match select team -> start match)
            NavigationStack {
                HomePreMatchView(
                    store: store,
                    teamStore: teamStore,
                    selectedTeamID: $selectedTeamID
                )
            }
            .tabItem { Label("Match", systemImage: "soccerball") }

            // STATS (placeholder)
            NavigationStack {
                Text("Stats")
                    .font(.system(size: 18, weight: .semibold))
            }
            .tabItem { Label("Stats", systemImage: "chart.bar") }

            // SETTINGS (placeholder)
            NavigationStack {
                Text("Settings")
                    .font(.system(size: 18, weight: .semibold))
            }
            .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .onAppear {
            if selectedTeamID == nil {
                selectedTeamID = teamStore.teams.first?.id
            }
        }
    }
}

