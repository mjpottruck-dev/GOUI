import SwiftUI

struct RosterHomeView: View {
    @State private var teamStore = TeamStore()

    @State private var showingCreateTeam = false
    @State private var editingTeam: Team? = nil

    var body: some View {
        NavigationStack {
            List {
                if teamStore.teams.isEmpty {
                    Text("No teams yet. Tap + to create one.")
                        .foregroundColor(.secondary)
                }

                ForEach(teamStore.teams) { team in
                    Button {
                        editingTeam = team
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(team.name).font(.headline)
                                Text("\(team.players.count) players • \(team.matches.count) matches")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .onDelete { idxSet in
                    for idx in idxSet {
                        let team = teamStore.teams[idx]
                        teamStore.deleteTeam(team)
                    }
                }
            }
            .navigationTitle("Teams")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingCreateTeam = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingCreateTeam) {
                CreateTeamView { newTeam in
                    teamStore.addTeam(newTeam)
                    showingCreateTeam = false
                }
            }
            .sheet(item: $editingTeam) { team in
                EditRosterView(team: team) { updated in
                    // Preserve matches (archive) just in case
                    var merged = updated
                    if let current = teamStore.teams.first(where: { $0.id == updated.id }) {
                        merged.matches = current.matches
                    }
                    teamStore.updateTeam(merged)
                }
            }
        }
    }
}

