import SwiftUI

struct GoStatsRootView: View {

    @StateObject private var store = MatchStore()
    @State private var selectedTeamID: UUID? = nil

    // TeamStore is @Observable (not ObservableObject) so do NOT use StateObject for it.
    private var teamStore = TeamStore()

    var body: some View {
        MainTabsView(store: store, teamStore: teamStore, selectedTeamID: $selectedTeamID)
    }
}

