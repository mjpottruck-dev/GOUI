import SwiftUI

struct EndMatchSheet: View {

    // ✅ Your project uses ObservableObject, so use @ObservedObject
    @ObservedObject var store: MatchStore

    var teamStore: TeamStore
    let teamID: UUID

    // ✅ Your reset/save flow needs these
    let team: Team
    let formation: Formation

    @Environment(\.dismiss) private var dismiss

    @State private var opponent: String = ""
    @State private var title: String = ""
    @State private var notes: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Match Info") {
                    TextField("Opponent", text: $opponent)
                    TextField("Title (optional)", text: $title)
                    TextField("Notes (optional)", text: $notes, axis: .vertical)
                        .lineLimit(3...8)
                }

                Section {
                    Button {
                        saveMatch()
                    } label: {
                        Text("Save Match")
                            .font(.system(size: 16, weight: .semibold))
                    }
                }
            }
            .navigationTitle("End Match")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }

    private func saveMatch() {
        // ✅ IMPORTANT: pass VALUES (no $store anywhere)
        let record = MatchRecord(
            id: UUID(),
            date: Date(),
            opponent: opponent,
            title: title,
            notes: notes,
            goalsFor: store.goalsFor,
            goalsAgainst: store.goalsAgainst,
            secondsElapsed: store.secondsElapsed,
            fieldSize: store.fieldSize,
            playerSeconds: store.playerSeconds,
            playerStats: store.playerStats
        )

        teamStore.addMatchRecord(teamID: teamID, record: record)

        // ✅ reset needs required args in your project
        store.resetForNewMatch(team: team, formation: formation)

        dismiss()
    }
}

